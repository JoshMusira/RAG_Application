import React from 'react'
import QuestionForm from '../components/QuestionForm'

const Conversation = () => {
    return (
        <div>
            <QuestionForm />
        </div>
    )
}

export default Conversation