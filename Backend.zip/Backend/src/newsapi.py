import requests
from decouple import config
import concurrent.futures

from src.qdrant import upload_website_to_collection

def search_news(query, start_date, end_date):
    api_key = config("NEWS_API_KEY")
    url = f"https://newsapi.org/v2/everything?q={query}&from={start_date}&to={end_date}&sources=cnn&pageSize=50&sortBy=publishedAt&apiKey={api_key}"
    response = requests.get(url)
    data = response.json()
    # print(data)

    try:
        urls = [article['url'] for article in data['articles']]
        print(urls)
        return urls
    except KeyError as e:
        print(f"Error: {e}")
        return []

# query = "Joe Biden OR Donald Trump"
# start_date = "2024-06-01"
# end_date = "2024-06-22"

def upload_news_to_collection(query, start_date, end_date):
    urls = search_news(query, start_date, end_date)
    print(f"Found {len(urls)} URLs.")

    failed_uploads = []

    def upload_with_logging(url):
        try:
            upload_website_to_collection(url)
        except Exception as e:
            print(f"Failed to upload {url}: {e}")
            failed_uploads.append(url)

    # Use ThreadPoolExecutor for parallel uploads
    with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
        executor.map(upload_with_logging, urls)

    if failed_uploads:
        print(f"Failed to upload the following URLs: {failed_uploads}")
    else:
        print("All URLs uploaded successfully.")

# def upload_news_to_collection(url, start_date, end_date):
#     # print(url)
#     # Search for news articles using OpenAI's API
#     urls = search_news(url, start_date, end_date)
#     print(len(urls))

#     # Upload each news article to the collection
#     for url in urls:
#         upload_website_to_collection(url)


# upload_news_to_collection(query, start_date, end_date)
